# @ryp/eco

The RYP ecosystem's shared spine: the **identity schema**, the **Firebase auth bridge**, and the **RLS database pool** — the single source of truth every RYP app imports instead of hand-copying.

## The most important thing to understand

**`public.*` is a MIRROR, not a migration.** Those tables already exist in the live database, already have RLS enabled and `FORCE`d, and already carry a working policy set. eco's job is to be the accurate *code representation* of that reality — types and table objects for foreign keys and queries — **not** to create or alter it.

| Schema | Who owns it | eco's role |
| --- | --- | --- |
| `public.*` | RYP-RED's drizzle config | **Mirror only.** Never migrated from eco (excluded in `drizzle.config.ts`) |
| `golf.*` | eco | Owned — but **declared and NOT yet provisioned** (see `src/schema/golf.ts`) |
| `ryp_red.*`, `locker_room.*`, `debrief.*`, `atlas.*` | each app | Not eco's business |

> **History worth knowing:** eco v0.1.0's `public.*` schema was written from design notes and never checked against the database. Nearly all of it was wrong — wrong primary keys on three tables, a completely wrong `user_relationships` shape, invented columns on `coach_profiles`, a missing `feature_flags`, wrong timestamp types, `ON DELETE CASCADE` that production doesn't have, a missing `'user'` role, and an invented parallel RLS policy set. Everything in this package was re-derived by reading the live database on 2026-08-05. **If you change the schema here, verify against production first.**

## Install

```bash
npm i github:RYPGolf/ryp-eco#v0.3.0
```

Git-pinned, not a registry package. `prepare` builds `dist/` on install; peer deps (`drizzle-orm`, `express`, `firebase-admin`, `pg`) come from the consuming app.

## What's in it

| Subpath | Exports | Purpose |
| --- | --- | --- |
| `@ryp/eco/schema` | `users`, `userAppRoles`, `userRelationships`, `coachProfiles`, `featureFlags`, `golfPlayerProfile`, `APPS`, `ROLES`, `PLANS`, `RELATIONSHIPS` + types | Drizzle schema for `public.*` (+ pending `golf.*`) |
| `@ryp/eco/auth` | `verifyToken`, `attachUser`, `requireApp`, `firebaseAuth` | Express middleware: token → identity → entitlement |
| `@ryp/eco/db` | `createEcoPool`, `withRls`, `withRlsBypass`, `RlsContext` | The RLS-scoped pg pool |

The root `@ryp/eco` re-exports all three; subpath imports are preferred in apps.

## The request pipeline

`verifyToken` → `attachUser(pool)` → `requireApp('atlas')` → your handler using `withRls`.

1. **`verifyToken`** — the *only* Firebase touchpoint. Verifies the `Bearer` ID token → `req.firebaseUid`. Everything after uses the resolved UUID, never the firebase uid.
2. **`attachUser(pool)`** — resolves `firebaseUid` → the `public.users` row (upserting on first login), loads the user's app entitlements → `req.user`, `req.appRoles`.
3. **`requireApp(app)`** — 403s unless the user has a role in `app` (reads `user_app_roles`, the entitlement gate). In-memory, no extra round-trip.
4. **`withRls(pool, ctx, appSchema, fn)`** — runs `fn` in a transaction with `app.current_user_id` / `app.firebase_uid` / `app.current_app` set **transaction-locally**, so RLS policies scope every row and nothing leaks across pooled requests. Pass your app's own schema; drizzle infers the types.

> There is deliberately **no unscoped drizzle handle**. Under `FORCE RLS` an unscoped query silently returns zero rows — a data-loss-looking trap.

### The escape hatch

Production's policies all check `app_private.rls_bypass()` first — that is how trusted, non-user-facing work (billing webhooks writing entitlements, `feature_flags` writes, admin backfills) gets done. `withRlsBypass(pool, reason, schema, fn)` sets that session var.

```ts
await withRlsBypass(pool, 'stripe webhook: grant atlas role', schema, (db) =>
  db.insert(userAppRoles).values({ userId, app: 'atlas', role: 'user' }),
)
```

⚠️ It disables per-user scoping for the whole transaction. Never call it from a route whose input is user-shaped. The required `reason` argument exists to make call sites self-documenting and greppable.

## How an app consumes it

```ts
import express from 'express'
import { verifyToken, attachUser, requireApp } from '@ryp/eco/auth'
import { createEcoPool, withRls } from '@ryp/eco/db'
import * as atlasSchema from './schema'   // the app's OWN schema (atlas.*)

const { pool } = createEcoPool()
const app = express()
app.use(express.json())

// shared identity route — any authenticated user
app.get('/api/me', verifyToken, attachUser(pool), (req, res) => res.json((req as any).user))

// app route — authenticated + entitled + RLS-scoped + typed
app.get('/api/atlas/things',
  verifyToken, attachUser(pool), requireApp('atlas'),
  async (req, res, next) => {
    try {
      const u = (req as any).user
      const rows = await withRls(
        pool,
        { userId: u.id, firebaseUid: u.firebaseUid, app: 'atlas' },
        atlasSchema,                              // → db.query.* fully typed, no cast
        (db) => db.query.things.findMany(),
      )
      res.json(rows)
    } catch (e) { next(e) }
  })
```

## Adopting it (per app)

1. `npm i github:RYPGolf/ryp-eco#v0.3.0`
2. Delete the hand-copied identity schema; re-export from `@ryp/eco/schema` instead. Downstream imports don't change.
3. Keep your own drizzle config scoped to **your** schema — never `public`.
4. Point `DATABASE_URL` at the shared Neon pooler; set `FIREBASE_*` for the shared project.

Your existing auth middleware and RLS pool can stay. eco's `verifyToken`/`withRls` are available but swapping them is a separate change with no urgency — Locker Room's implementation predates this package and works.

## Env vars

```bash
DATABASE_URL=            # Neon POOLER url for the shared neondb
FIREBASE_PROJECT_ID=rypstick-ios
FIREBASE_CLIENT_EMAIL=
FIREBASE_PRIVATE_KEY=    # PEM; \n-escaped
```

## RLS policies

`sql/rls_public.sql` is a **faithful reproduction of the live policies**, dumped from production. It is **already applied** — do not run it against the live database. It exists as documentation and to bootstrap a fresh environment (Neon dev branch, local Postgres, CI). Every statement is `drop ... if exists`-guarded so it is re-runnable, which matters because a Neon dev branch is a copy-on-write clone of production and therefore already has the policies.

It also carries the four `app_private.locker_room_*` helper functions, which **exist in no repository** — Locker Room's migrations reference them but define them nowhere, so they were created directly against the live database. This file is currently their only version-controlled record.

## 🚩 Known gaps in the live database

Found while verifying this package. **Neither is fixed** — both need a decision, and both are documented with the fix and a falsification test in `sql/rls_public.sql`.

1. **RLS is currently inert.** Every login-capable Postgres role has `BYPASSRLS`, including `neondb_owner` — which is what `DATABASE_URL` connects as. `BYPASSRLS` defeats `FORCE RLS` entirely, so today the policies are decorative and `withRls` is behaviourally identical to `withRlsBypass`. The fix is a dedicated non-bypassing role (`Part 0` of the SQL file). ⚠️ Sequencing trap: two `app_private` helpers are `SECURITY INVOKER` and select the very table whose policies call them, which may recurse once RLS actually binds — reproduce on a dev branch first.

2. **Self-grant privilege escalation.** The live `user_app_roles_all` policy constrains `user_id` but not `app` or `role`, so a user can insert their own `('locker_room','admin')` row — which activates `users_locker_admin_read` and exposes every row of `public.users`. Not exploitable today only because no route lets a user choose app/role. The fix (bypass-only writes) is a **breaking change for Locker Room**, which self-provisions role rows; coordinate before applying.

Verify claim 1 yourself:

```bash
psql "$DATABASE_URL" -c "select rolname, rolbypassrls from pg_roles where rolname not like 'pg\_%';"
```

## Production quirks captured deliberately

- `public.users`' primary key constraint is named **`players_pkey`** — a fossil from when the table was called `players`. Don't let a generated migration "fix" it.
- `(user_id, app)` uniqueness on `user_app_roles` and `stripe_customer_id` on `users` are bare **unique indexes**, not constraints.
- Timestamps are `timestamp without time zone` throughout. Do not add `withTimezone: true`.
- Foreign keys have **no `ON DELETE` clause**. Users are soft-deleted via `deleted_at`.
- `public.user_relationships` uses **`actor_user_id` / `subject_user_id`** with a `relationship` label and `status` defaulting to `'pending'` — it is a request until `approved_at` is set. It has 0 rows today, so its vocabulary is provisional.

## Scripts

| Script | Does |
| --- | --- |
| `npm run build` | tsup → dual ESM+CJS, then `tsc` → `.d.ts` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run verify:schema` | Diffs eco's declared schema against the live DB (needs `DATABASE_URL`) and exits non-zero on drift. Read its header for what it does *not* check |
| `npm run db:generate` | drizzle-kit generate — **`golf` only**, because `drizzle.config.ts` points `schema` at `golf.ts`, not the barrel. `schemaFilter` alone does **not** achieve this (verified: with the barrel it emitted `CREATE TABLE` for all five public tables) |
| `npm run db:migrate` | drizzle-kit migrate |
